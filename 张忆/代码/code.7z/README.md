# SVM Project

## SVM_Project1
简化版 SMO 算法

## SVM_Project2
完整版 SMO 算法

## SVM_Project3
加入核函数的完整版 SMO 算法

## SVM_Project4
使用 SVM_Project3 对 MNIST 分类，数据集仅含 1 和 7

## SVM_Project5
使用 sklearn 对 MNIST 分类，数据集仅含 1 和 7
